package com.example.wordlist;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class Quiz extends AppCompatActivity {
    MySQLiteHandler handler;
    Cursor c;
    SimpleCursorAdapter adapter;
    MySQLiteOpenHelper helper;
    SQLiteDatabase db;
    Context ctx;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    //설정
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_setting:
                Intent intent = new Intent(getApplicationContext(), Setting.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quiz_one);

        TextView quiz_content = findViewById(R.id.quiz_content);

        Button btnQuiz_ans_1 = findViewById(R.id.btnQuiz_ans_1);
        Button btnQuiz_ans_2 = findViewById(R.id.btnQuiz_ans_2);
        Button btnQuiz_ans_3 = findViewById(R.id.btnQuiz_ans_3);

        handler = MySQLiteHandler.open(getApplicationContext());
        c = handler.selectAll();
        startManagingCursor(c);


        btnQuiz_ans_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "정답입니다!", Toast.LENGTH_SHORT).show();
            }
        });
        btnQuiz_ans_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        btnQuiz_ans_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
}

